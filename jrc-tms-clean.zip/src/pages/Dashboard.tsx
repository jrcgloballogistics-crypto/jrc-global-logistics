import { useEffect, useState } from 'react'
import { supabase, errMsg } from '../lib/supabase'
type S = { parties: number; tripsMonth: number; inTransit: number; delivered: number }
export default function Dashboard({ go }: { go: (p: 'parties') => void }) {
  const [s, setS] = useState<S | null>(null); const [err, setErr] = useState('')
  useEffect(() => {
    (async () => {
      try {
        const d = new Date(); const start = new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10)
        const count = async (q: any) => { const { count, error } = await q; if (error) throw error; return count ?? 0 }
        const [parties, tripsMonth, inTransit, delivered] = await Promise.all([
          count(supabase.from('parties').select('*', { count: 'exact', head: true }).eq('active', true)),
          count(supabase.from('trips').select('*', { count: 'exact', head: true }).gte('trip_date', start).neq('status', 'cancelled')),
          count(supabase.from('trips').select('*', { count: 'exact', head: true }).eq('status', 'in_transit')),
          count(supabase.from('trips').select('*', { count: 'exact', head: true }).gte('trip_date', start).eq('status', 'delivered'))])
        setS({ parties, tripsMonth, inTransit, delivered })
      } catch (e) { setErr(errMsg(e)) }
    })()
  }, [])
  if (err) return <p className="err">Could not load dashboard: {err}</p>
  if (!s) return <p>Loading…</p>
  return <><h1>Dashboard</h1><p className="muted">Live counts from your database. Billing, receivables and profit tiles arrive with the trip and invoice modules (Phases 3–4).</p>
    <div className="kpis">
      <button className="kpi" onClick={() => go('parties')}><b>{s.parties}</b>Active parties</button>
      <div className="kpi"><b>{s.tripsMonth}</b>Trips this month</div>
      <div className="kpi"><b>{s.inTransit}</b>In transit</div>
      <div className="kpi"><b>{s.delivered}</b>Delivered this month</div></div></>
}
