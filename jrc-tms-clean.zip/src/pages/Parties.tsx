import { useEffect, useState, FormEvent, useCallback } from 'react'
import { supabase, errMsg } from '../lib/supabase'
import { useAuth } from '../auth/AuthContext'
type Party = { id: string; name: string; gstin: string | null; contact: string | null; payment_terms_days: number; active: boolean }
const GST = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/
export default function Parties() {
  const { profile } = useAuth()
  const [rows, setRows] = useState<Party[]>([]); const [q, setQ] = useState(''); const [loading, setLoading] = useState(true)
  const [err, setErr] = useState(''); const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false)
  const [f, setF] = useState({ name: '', gstin: '', contact: '', terms: '30', address: '' }); const [fe, setFe] = useState('')
  const load = useCallback(async () => {
    setLoading(true); const { data, error } = await supabase.from('parties').select('id,name,gstin,contact,payment_terms_days,active').order('name')
    if (error) setErr(errMsg(error)); else { setRows(data as Party[]); setErr('') }
    setLoading(false)
  }, [])
  useEffect(() => { load() }, [load])
  async function save(e: FormEvent) {
    e.preventDefault(); setFe('')
    const gst = f.gstin.trim().toUpperCase(); const terms = Number(f.terms)
    if (f.name.trim().length < 2) return setFe('Party name is required.')
    if (gst && !GST.test(gst)) return setFe('GSTIN format is invalid (15 characters).')
    if (f.contact && !/^[0-9+\- ]{7,15}$/.test(f.contact)) return setFe('Contact number looks invalid.')
    if (!Number.isInteger(terms) || terms < 0 || terms > 365) return setFe('Payment terms must be 0–365 days.')
    setBusy(true)
    const { error } = await supabase.from('parties').insert({ org_id: profile!.org_id, name: f.name.trim(), gstin: gst || null, contact: f.contact || null, billing_address: f.address || null, payment_terms_days: terms })
    setBusy(false)
    if (error) return setFe(error.code === '23505' ? 'A party with this name already exists.' : errMsg(error))
    setF({ name: '', gstin: '', contact: '', terms: '30', address: '' }); setOpen(false); load()
  }
  async function toggle(p: Party) {
    const { error } = await supabase.from('parties').update({ active: !p.active }).eq('id', p.id)
    if (error) setErr(errMsg(error)); else load()
  }
  const shown = rows.filter(r => r.name.toLowerCase().includes(q.toLowerCase()))
  return <><div className="row"><h1>Parties</h1><button className="btn sm" onClick={() => setOpen(!open)}>{open ? 'Close' : '+ Add party'}</button></div>
    {open && <form className="card" onSubmit={save} noValidate>
      <label>Party name *<input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></label>
      <label>GSTIN<input value={f.gstin} maxLength={15} onChange={e => setF({ ...f, gstin: e.target.value })} /></label>
      <label>Contact number<input inputMode="tel" value={f.contact} onChange={e => setF({ ...f, contact: e.target.value })} /></label>
      <label>Payment terms (days)<input inputMode="numeric" value={f.terms} onChange={e => setF({ ...f, terms: e.target.value })} /></label>
      <label>Billing address<textarea rows={2} value={f.address} onChange={e => setF({ ...f, address: e.target.value })} /></label>
      {fe && <p className="err" role="alert">{fe}</p>}<button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Save party'}</button></form>}
    <input className="search" placeholder="Search parties" value={q} onChange={e => setQ(e.target.value)} />
    {err && <p className="err">{err}</p>}{loading && <p>Loading…</p>}
    {!loading && !shown.length && <p className="muted">{rows.length ? 'No match.' : 'No parties yet. Tap “+ Add party”.'}</p>}
    <div className="list">{shown.map(p => <div key={p.id} className={p.active ? 'item' : 'item off'}>
      <div><b>{p.name}</b><div className="muted">{p.gstin ?? 'No GSTIN'} · {p.contact ?? 'No phone'} · {p.payment_terms_days} days</div></div>
      <button className="btn sm ghost" onClick={() => toggle(p)}>{p.active ? 'Deactivate' : 'Activate'}</button></div>)}</div></>
}
