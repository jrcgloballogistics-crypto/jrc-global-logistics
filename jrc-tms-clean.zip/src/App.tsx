import { useState, FormEvent } from 'react'
import { useAuth } from './auth/AuthContext'
import { configured, supabase, errMsg } from './lib/supabase'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Parties from './pages/Parties'

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return <main className="center"><div className="card auth"><h1>JRC Global Logistics</h1><h2>{title}</h2>{children}</div></main>
}

function Login() {
  const [mode, setMode] = useState<'in' | 'up' | 'reset'>('in')
  const [email, setEmail] = useState(''); const [pw, setPw] = useState('')
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [ok, setOk] = useState('')
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(''); setOk('')
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr('Enter a valid email address.')
    if (mode !== 'reset' && pw.length < 8) return setErr('Password must be at least 8 characters.')
    setBusy(true)
    try {
      if (mode === 'in') { const { error } = await supabase.auth.signInWithPassword({ email, password: pw }); if (error) throw error }
      else if (mode === 'up') { const { data, error } = await supabase.auth.signUp({ email, password: pw }); if (error) throw error; if (!data.session) setOk('Check your email to confirm your account, then sign in.') }
      else { const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin }); if (error) throw error; setOk('If that email exists, a reset link has been sent.') }
    } catch (x) { setErr(errMsg(x)) } finally { setBusy(false) }
  }
  return <Card title={mode === 'in' ? 'Sign in' : mode === 'up' ? 'Create owner account' : 'Reset password'}>
    <form onSubmit={submit} noValidate>
      <label>Email<input type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label>
      {mode !== 'reset' && <label>Password<input type="password" autoComplete={mode === 'in' ? 'current-password' : 'new-password'} value={pw} onChange={e => setPw(e.target.value)} /></label>}
      {err && <p className="err" role="alert">{err}</p>}{ok && <p className="okmsg">{ok}</p>}
      <button className="btn" disabled={busy}>{busy ? 'Please wait…' : mode === 'in' ? 'Sign in' : mode === 'up' ? 'Create account' : 'Send reset link'}</button>
    </form>
    <p className="links">
      {mode !== 'in' && <a onClick={() => setMode('in')}>Sign in</a>}
      {mode === 'in' && <a onClick={() => setMode('reset')}>Forgot password?</a>}
      {mode === 'in' && <a onClick={() => setMode('up')}>First time setup</a>}
    </p>
  </Card>
}

function NewPassword() {
  const { done } = useAuth(); const [pw, setPw] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  async function submit(e: FormEvent) {
    e.preventDefault(); if (pw.length < 8) return setErr('Password must be at least 8 characters.')
    setBusy(true); const { error } = await supabase.auth.updateUser({ password: pw }); setBusy(false)
    if (error) setErr(errMsg(error)); else done()
  }
  return <Card title="Set a new password"><form onSubmit={submit}><label>New password<input type="password" autoComplete="new-password" value={pw} onChange={e => setPw(e.target.value)} /></label>{err && <p className="err">{err}</p>}<button className="btn" disabled={busy}>Save password</button></form></Card>
}

function Setup() {
  const { refresh } = useAuth(); const [company, setCompany] = useState('JRC Global Logistics'); const [name, setName] = useState('')
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  async function submit(e: FormEvent) {
    e.preventDefault(); if (company.trim().length < 2) return setErr('Company name is required.')
    setBusy(true); const { error } = await supabase.rpc('bootstrap_org', { p_name: company, p_full_name: name })
    if (error) { setErr(errMsg(error)); setBusy(false) } else { await refresh(); setBusy(false) }
  }
  return <Card title="Company setup"><p>You are the first user, so you will be the administrator.</p><form onSubmit={submit}>
    <label>Company name<input value={company} onChange={e => setCompany(e.target.value)} /></label>
    <label>Your name<input value={name} onChange={e => setName(e.target.value)} /></label>
    {err && <p className="err">{err}</p>}<button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Create company'}</button></form></Card>
}

export default function App() {
  const { session, profile, loading, recovery } = useAuth()
  const [page, setPage] = useState<'dashboard' | 'parties'>('dashboard')
  if (!configured) return <Card title="Not configured"><p>Supabase URL and anon key are missing. Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> in Netlify environment variables, then redeploy. See SETUP.md.</p></Card>
  if (loading) return <Card title="Loading…"><p>Please wait.</p></Card>
  if (recovery) return <NewPassword />
  if (!session) return <Login />
  if (!profile) return <Setup />
  return <Layout page={page} setPage={setPage}>{page === 'dashboard' ? <Dashboard go={setPage} /> : <Parties />}</Layout>
}
