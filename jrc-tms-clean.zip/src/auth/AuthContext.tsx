import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'

export type Profile = { id: string; org_id: string; full_name: string | null; role: 'admin' | 'staff' }
type Ctx = { session: Session | null; profile: Profile | null; loading: boolean; recovery: boolean; refresh: () => Promise<void>; done: () => void }
const C = createContext<Ctx>(null as unknown as Ctx)
export const useAuth = () => useContext(C)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [recovery, setRecovery] = useState(false)

  const load = useCallback(async (s: Session | null) => {
    if (!s) { setProfile(null); return }
    const { data } = await supabase.from('profiles').select('id,org_id,full_name,role').eq('id', s.user.id).maybeSingle()
    setProfile((data as Profile) ?? null)
  }, [])

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => { setSession(data.session); await load(data.session); setLoading(false) })
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s)
      if (event === 'PASSWORD_RECOVERY') setRecovery(true)
      setTimeout(() => { load(s) }, 0) // avoid deadlock inside auth callback
    })
    return () => sub.subscription.unsubscribe()
  }, [load])

  return <C.Provider value={{ session, profile, loading, recovery, refresh: () => load(session), done: () => setRecovery(false) }}>{children}</C.Provider>
}
