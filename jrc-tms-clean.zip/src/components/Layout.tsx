import { ReactNode } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../auth/AuthContext'
type P = 'dashboard' | 'parties'
const NAV: { id: P; label: string; icon: string }[] = [{ id: 'dashboard', label: 'Dashboard', icon: '▦' }, { id: 'parties', label: 'Parties', icon: '👥' }]
export default function Layout({ page, setPage, children }: { page: P; setPage: (p: P) => void; children: ReactNode }) {
  const { profile } = useAuth()
  return <div className="shell">
    <aside className="side"><div className="brand">JRC<small>Global Logistics</small></div>
      {NAV.map(n => <button key={n.id} className={page === n.id ? 'nav on' : 'nav'} onClick={() => setPage(n.id)}>{n.icon} {n.label}</button>)}
      <div className="grow" /><div className="who">{profile?.full_name ?? 'User'} · {profile?.role}</div>
      <button className="nav" onClick={() => supabase.auth.signOut()}>Sign out</button></aside>
    <header className="top"><b>JRC TMS</b><button className="link" onClick={() => supabase.auth.signOut()}>Sign out</button></header>
    <section className="main">{children}</section>
    <nav className="tabs">{NAV.map(n => <button key={n.id} className={page === n.id ? 'on' : ''} onClick={() => setPage(n.id)}><span>{n.icon}</span>{n.label}</button>)}</nav>
  </div>
}
