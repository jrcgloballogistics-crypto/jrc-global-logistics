# JRC Global Logistics TMS - Phase 1: Architecture

## Stack
- Frontend: React + TypeScript (Vite), hosted on Netlify from GitHub
- Backend/DB: Supabase (PostgreSQL, Auth, Storage, Row Level Security)
- Business logic that must not be bypassed (invoice posting, payment allocation, numbering) lives in
  Postgres functions / Supabase Edge Functions, called with an idempotency key.
- Secrets: only the public anon key is in the frontend. The service-role key stays in server env only.

## Core flow (single source of truth = the trip row)
Trip -> LR (bilty) -> Delivered -> Invoice (one trip billed once) -> Receipt allocation
Trip -> Transporter payout -> Payment allocations. Expenses allocate to a trip OR stay general.

## Accounting formulas
- Billing = sum of posted invoice taxable values (accrual, tax shown separately)
- Collections = sum of posted receipts (cash basis)
- Receivable = opening + invoices - receipts allocated/unallocated
- Payable = opening + transporter freight - payments
- Trip contribution = party_amount - payout_amount - expenses allocated to that trip
- Net profit = sum of contributions - general (unallocated) expenses

## Rules baked into the schema
- Money numeric(14,2), quantity numeric(12,3); no floats
- Rate snapshot is copied onto the trip, so later rate changes never alter history
- unique(trip_id) on invoice_lines blocks double billing; idempotency keys block duplicate payments
- Document numbers come from next_doc_no() (atomic counter), safe under concurrent users
- Posted rows are reversed, never deleted; GST stays "draft pending confirmation" until confirmed
- Destinations are structured locations (kind: loading/destination/port/mine), so the Dariba Mines
  report filters on fields, not text

## Phases
1. Plan + schema (this) | 2. Repo, auth, layout | 3. Masters, trips, rate engine
4. LR, invoices, receipts, payments, expenses, ledgers | 5. Reports, import, notifications
6. Security, tests, backup | 7. Deploy + mobile acceptance

## Needs from you (cannot be done for you)
- A free Supabase project (supabase.com) and a GitHub account + Netlify account
- Confirmation of GST treatment for your invoices (ask your CA), before invoices are marked final
- Invoice/LR number prefixes you want
