# Setup (iPhone-friendly) - JRC TMS
1. supabase.com > sign up > New project (note the database password). Wait until ready.
2. Project > SQL Editor > New query: paste 0001_core_schema.sql > Run. Then paste 0002_auth_bootstrap.sql > Run. Fix any red error before continuing.
3. Project Settings > API: copy Project URL and the "anon public" key (never the service_role key).
4. github.com > new private repository > upload this folder's files (Add file > Upload files; keep the folder structure).
5. netlify.com > Add new site > Import from GitHub > pick the repo. Build command: npm run build, publish dir: dist.
6. Netlify > Site settings > Environment variables: add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY. Redeploy.
7. Supabase > Authentication > URL Configuration: set Site URL to your Netlify address.
8. Open the site on iPhone Safari > First time setup > create owner account > confirm email > sign in > Company setup.
9. Supabase > Authentication > Providers/Sign-in: turn OFF "Allow new users to sign up" so strangers cannot create companies.
10. Safari > Share > Add to Home Screen.
Desktop-only: none strictly, but SQL pasting is easier on a larger screen.
