-- JRC Global Logistics TMS - Phase 1 core schema (PostgreSQL / Supabase)
-- Money: numeric(14,2). Quantity (MT): numeric(12,3). Rates: numeric(12,2). No floats.
-- Posted financial rows are never deleted: use status + reversal.

create extension if not exists "pgcrypto";

create type user_role as enum ('admin','staff');
create type trip_status as enum ('draft','planned','vehicle_assigned','reported','loaded','in_transit',
  'delivered','billing_pending','billed','partially_paid','paid','cancelled');
create type billing_unit as enum ('per_mt','per_vehicle','per_trip');
create type doc_status as enum ('draft','posted','cancelled','reversed');

create table organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null, gstin text, address text, phone text,
  settings jsonb not null default '{}', created_at timestamptz not null default now()
);

create table profiles (  -- one row per auth.users
  id uuid primary key references auth.users(id) on delete cascade,
  org_id uuid not null references organizations(id),
  full_name text, role user_role not null default 'staff', active boolean not null default true
);

create table parties (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  name text not null, billing_address text, gstin text, contact text,
  payment_terms_days int not null default 30, opening_balance numeric(14,2) not null default 0,
  credit_limit numeric(14,2), active boolean not null default true,
  unique (org_id, name)
);

create table transporters (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  name text not null, phone text, bank_details jsonb,  -- restrict via RLS/admin only
  opening_balance numeric(14,2) not null default 0, active boolean not null default true,
  unique (org_id, name)
);

create table vehicles (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  reg_no text not null, vehicle_type text, capacity_mt numeric(12,3),
  transporter_id uuid references transporters(id),
  doc_expiry jsonb not null default '{}', active boolean not null default true,
  unique (org_id, reg_no)
);

create table drivers (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  name text not null, phone text, licence_no text, licence_expiry date,
  vehicle_id uuid references vehicles(id), active boolean not null default true
);

create table locations (  -- structured, so reports filter on real fields, not text
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  name text not null, kind text not null check (kind in ('loading','destination','port','mine')),
  unique (org_id, name, kind)
);

create table freight_rates (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  party_id uuid not null references parties(id),
  loading_id uuid references locations(id),
  destination_id uuid not null references locations(id),
  vehicle_type text, material text,
  party_unit billing_unit not null default 'per_mt', party_rate numeric(12,2) not null,
  payout_unit billing_unit not null default 'per_vehicle', payout_rate numeric(12,2),
  effective_from date not null, effective_to date,
  approved boolean not null default false,
  check (effective_to is null or effective_to >= effective_from)
);
create index on freight_rates (org_id, party_id, destination_id, effective_from);

create table doc_counters (  -- gap-free, concurrency-safe numbering via update ... returning
  org_id uuid not null references organizations(id),
  doc_type text not null, fy text not null, last_no int not null default 0,
  primary key (org_id, doc_type, fy)
);

create or replace function next_doc_no(p_org uuid, p_type text, p_fy text, p_prefix text)
returns text language plpgsql as $$
declare n int;
begin
  insert into doc_counters(org_id,doc_type,fy,last_no) values (p_org,p_type,p_fy,1)
  on conflict (org_id,doc_type,fy) do update set last_no = doc_counters.last_no + 1
  returning last_no into n;
  return p_prefix || '/' || p_fy || '/' || lpad(n::text,4,'0');
end $$;

create table trips (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  trip_no text not null, trip_date date not null,
  party_id uuid not null references parties(id),
  loading_id uuid references locations(id), destination_id uuid references locations(id),
  vehicle_id uuid references vehicles(id), transporter_id uuid references transporters(id),
  driver_id uuid references drivers(id),
  material text, qty_mt numeric(12,3), lr_no text, eway_bill_no text, eway_valid_till timestamptz,
  -- rate snapshot: stays stable if master rate changes later
  rate_id uuid references freight_rates(id),
  party_unit billing_unit, party_rate numeric(12,2), party_amount numeric(14,2),
  payout_unit billing_unit, payout_rate numeric(12,2), payout_amount numeric(14,2),
  advance_paid numeric(14,2) not null default 0,
  reported_at timestamptz, loaded_at timestamptz, delivered_at timestamptz,
  status trip_status not null default 'draft', notes text,
  idempotency_key text, created_by uuid references profiles(id), created_at timestamptz not null default now(),
  unique (org_id, trip_no), unique (org_id, idempotency_key)
);
create index on trips (org_id, trip_date desc);
create index on trips (org_id, status);

create table trip_status_history (
  id bigserial primary key, trip_id uuid not null references trips(id),
  from_status trip_status, to_status trip_status not null,
  changed_by uuid references profiles(id), changed_at timestamptz not null default now()
);

create table invoices (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  invoice_no text, party_id uuid not null references parties(id),
  invoice_date date not null, due_date date,
  taxable_value numeric(14,2) not null default 0, tax_amount numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0, gst_confirmed boolean not null default false, -- false = draft pending tax confirmation
  status doc_status not null default 'draft', unique (org_id, invoice_no)
);
create table invoice_lines (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id), trip_id uuid not null references trips(id),
  description text, qty numeric(12,3), rate numeric(12,2), amount numeric(14,2) not null,
  unique (trip_id)  -- a trip can be billed only once (blocks duplicate billing)
);

create table receipts (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  party_id uuid not null references parties(id), receipt_date date not null,
  amount numeric(14,2) not null check (amount > 0), method text, reference text,
  status doc_status not null default 'posted', idempotency_key text, unique (org_id, idempotency_key)
);
create table receipt_allocations (
  receipt_id uuid not null references receipts(id), invoice_id uuid not null references invoices(id),
  amount numeric(14,2) not null check (amount > 0), primary key (receipt_id, invoice_id)
);

create table transporter_payments (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  transporter_id uuid not null references transporters(id), pay_date date not null,
  amount numeric(14,2) not null check (amount > 0), kind text not null check (kind in ('advance','part','full')),
  method text, reference text, status doc_status not null default 'posted',
  idempotency_key text, unique (org_id, idempotency_key)
);
create table payment_allocations (
  payment_id uuid not null references transporter_payments(id), trip_id uuid not null references trips(id),
  amount numeric(14,2) not null check (amount > 0), primary key (payment_id, trip_id)
);

create table expenses (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id),
  expense_date date not null, category text not null, amount numeric(14,2) not null check (amount > 0),
  trip_id uuid references trips(id),  -- null = general business expense; set = allocated to that trip only (no double count)
  notes text, status doc_status not null default 'posted'
);

create table audit_logs (
  id bigserial primary key, org_id uuid not null, user_id uuid, action text not null,
  entity text not null, entity_id text, details jsonb, at timestamptz not null default now()
);

-- Row-level security: every table scoped to the caller's organization.
create or replace function my_org() returns uuid language sql stable security definer as
$$ select org_id from profiles where id = auth.uid() and active $$;

do $$
declare t text;
begin
  foreach t in array array['parties','transporters','vehicles','drivers','locations','freight_rates',
    'trips','invoices','receipts','transporter_payments','expenses'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy org_isolation on %I using (org_id = my_org()) with check (org_id = my_org())', t);
  end loop;
end $$;
