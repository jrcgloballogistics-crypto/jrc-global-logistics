-- Phase 2: RLS for org/profile tables, admin helper, first-login company setup.
create or replace function is_admin() returns boolean language sql stable security definer as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and active) $$;

alter table organizations enable row level security;
alter table profiles enable row level security;
-- Tables below get RLS now with NO client policy = denied to browsers until their module ships.
alter table trip_status_history enable row level security;
alter table invoice_lines enable row level security;
alter table receipt_allocations enable row level security;
alter table payment_allocations enable row level security;
alter table doc_counters enable row level security;
alter table audit_logs enable row level security;

create policy org_read on organizations for select using (id = my_org());
create policy org_update on organizations for update using (id = my_org() and is_admin()) with check (id = my_org());
create policy profile_read on profiles for select using (id = auth.uid() or org_id = my_org());
create policy audit_read on audit_logs for select using (org_id = my_org() and is_admin());

-- First user creates the company and becomes admin. Does nothing if profile already exists.
create or replace function bootstrap_org(p_name text, p_full_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_org uuid;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if exists (select 1 from profiles where id = auth.uid()) then
    return (select org_id from profiles where id = auth.uid());
  end if;
  if length(trim(coalesce(p_name,''))) < 2 then raise exception 'Company name is required'; end if;
  insert into organizations(name) values (trim(p_name)) returning id into v_org;
  insert into profiles(id, org_id, full_name, role) values (auth.uid(), v_org, nullif(trim(p_full_name),''), 'admin');
  insert into audit_logs(org_id, user_id, action, entity, entity_id) values (v_org, auth.uid(), 'create', 'organization', v_org::text);
  return v_org;
end $$;
revoke all on function bootstrap_org(text,text) from public;
grant execute on function bootstrap_org(text,text) to authenticated;
